# Javaweb_bookstore
This is a project for simulating a online bookstore<br>
Use Servlet+JSP+javaBean and follow MVC model
