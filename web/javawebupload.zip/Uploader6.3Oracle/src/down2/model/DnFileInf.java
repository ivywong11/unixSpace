package down2.model;

public class DnFileInf extends  up6.model.FileInf
{
	public DnFileInf(){}
	
	public String f_id = "";
	public String fileUrl = "";
	public String sizeSvr = "0byte";
	public String perLoc = "0%";
}