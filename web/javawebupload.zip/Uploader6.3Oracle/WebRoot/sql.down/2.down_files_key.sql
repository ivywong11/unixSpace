--创建主键
ALTER TABLE down_files ADD CONSTRAINT PK_down_files PRIMARY KEY(f_id)