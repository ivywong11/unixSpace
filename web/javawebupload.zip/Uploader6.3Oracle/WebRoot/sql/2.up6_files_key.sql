--创建主键
ALTER TABLE up6_files ADD CONSTRAINT PK_up6_files PRIMARY KEY(f_id)