--创建主键
ALTER TABLE up6_folders ADD CONSTRAINT PK_up6_folders PRIMARY KEY(fd_id)
