package com.koushikdutta.async.http.server;

public class MalformedRangeException extends Exception {
}
