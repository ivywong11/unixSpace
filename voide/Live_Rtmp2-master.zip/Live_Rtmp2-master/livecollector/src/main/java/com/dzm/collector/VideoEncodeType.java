package com.dzm.collector;

/**
 * Created by 83642 on 2017/8/29.
 */

public enum VideoEncodeType {

    SOFT,HARD

}
