package com.dzm.live;

/**
 * Created by 83642 on 2017/9/2.
 */

public interface OnRtmpConnectListener {

    void rtmpConnect(String msg,int code);

}
