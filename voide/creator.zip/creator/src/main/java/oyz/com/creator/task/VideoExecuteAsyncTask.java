//package oyz.com.creator.task;
//
//import android.graphics.Bitmap;
//import android.support.annotation.NonNull;
//
//import org.jcodec.api.android.AndroidSequenceEncoder;
//
//import java.io.File;
//import java.io.IOException;
//
//import oyz.com.creator.handler.CreatorExecuteResponseHander;
//import oyz.com.creator.IProvider;
//
//public class VideoExecuteAsyncTask extends BaseExecuteAsyncTask {
//
//    protected VideoExecuteAsyncTask(IProvider<Bitmap> provider, int fps, CreatorExecuteResponseHander<String> hander, String path) {
//        super(provider, fps, hander, path);
//    }
//
//    @Override
//    protected String doInBackground(Void... voids) {
//        _publishProgress(0);
//        //初始化
//        AndroidSequenceEncoder encoder = null;
//        try {
//            File file = new File(mPath);
//            encoder = AndroidSequenceEncoder.createSequenceEncoder(file, fps);
//            _publishProgress(2);
//
//            if (mProvider.size() > 0) {
//
//                if (isCancelled()) return null;
//                int i = 0;
//                while (mProvider.hasNext()) {
//                    encoder.encodeImage(mProvider.next());
////                    Thread.sleep(100);
//                    _publishProgress(i * 96 / mProvider.size() + 2);
//                    i++;
//
//                }
//
//            }
//
//            _publishProgress(98);
//            encoder.finish();
//            _publishProgress(100);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//            mHandler.onFailure(e.getMessage());
//            return null;
//        } catch (Exception e) {
//            e.printStackTrace();
//            mHandler.onFailure(e.getMessage());
//            return null;
//        }
//
//        return mPath;
//    }
//
//    public static void execute(@NonNull IProvider<Bitmap> provider, int delay, @NonNull CreatorExecuteResponseHander handler, @NonNull String path) {
//        try {
//            VideoExecuteAsyncTask asyncTask = new VideoExecuteAsyncTask(provider, delay, handler, path);
//            asyncTask.execute();
//        } catch (Exception e) {
//            e.printStackTrace();
//            handler.onFailure(e.getMessage());
//        }
//    }
//
//}
//
