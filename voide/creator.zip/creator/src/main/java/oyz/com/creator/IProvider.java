package oyz.com.creator;

public interface IProvider<T> {
    boolean hasNext();
    int size();
    T next();
}
