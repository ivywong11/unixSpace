package oyz.com.creator.task;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import oyz.com.creator.encoder.AnimatedGifEncoder;
import oyz.com.creator.handler.CreatorExecuteResponseHander;
import oyz.com.creator.IProvider;

public class GIFExecuteAsyncTask extends AsyncTask<Void, Integer, String> {

    private final CreatorExecuteResponseHander mHander;
    private final IProvider<Bitmap> mProvider;
    private final int fps;
    private final String mPath;

    private GIFExecuteAsyncTask(IProvider<Bitmap> provider, int fps, CreatorExecuteResponseHander<String> hander, String path) {
        this.mHander = hander;
        this.mProvider = provider;
        this.fps = fps;
        this.mPath = path;
    }

    @Override
    protected void onPreExecute() {
        mHander.onStart();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        if (values.length > 0 && values[0] != null && mHander != null) {
            mHander.onProgress(values[0].toString());
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if (result != null) {
            mHander.onSuccess(result);
        } else {
            mHander.onFailure("结果为空!");
        }
        mHander.onFinish();
    }

    private void _publishProgress(int process) {
        publishProgress(process);
    }

    @Override
    protected String doInBackground(Void... voids) {

        _publishProgress(0);
        OutputStream baos = null;
        try {
            //初始化
            baos = new FileOutputStream(mPath);
            AnimatedGifEncoder localAnimatedGifEncoder = new AnimatedGifEncoder();
            localAnimatedGifEncoder.start(baos);
            localAnimatedGifEncoder.setRepeat(0);
            localAnimatedGifEncoder.setFrameRate(fps); //setDelay(delay);
            _publishProgress(2);
            if (mProvider.size() > 0) {

                if (isCancelled()) return null;
                int i = 0;
                while (mProvider.hasNext()) {
                    localAnimatedGifEncoder.addFrame(mProvider.next());
                    _publishProgress(i * 90 / mProvider.size() + 2);
                    i++;
                }

            }

            _publishProgress(92);
            localAnimatedGifEncoder.finish();

            _publishProgress(95);
            baos.flush();
            _publishProgress(98);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            mHander.onFailure(e.getMessage());
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            mHander.onFailure(e.getMessage());
            return null;
        } finally {
            try {
                if (baos != null)
                    baos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        _publishProgress(100);
        return mPath;
    }

    public static void execute(@NonNull IProvider<Bitmap> provider, int delay, @NonNull CreatorExecuteResponseHander handler, @NonNull String path) {
        try {
            GIFExecuteAsyncTask asyncTask = new GIFExecuteAsyncTask(provider, delay, handler, path);
            asyncTask.execute();
        } catch (Exception e) {
            e.printStackTrace();
            handler.onFailure(e.getMessage());
        }
    }
}
