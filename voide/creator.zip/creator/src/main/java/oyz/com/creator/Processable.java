package oyz.com.creator;

public interface Processable {
    void onProcess(int process);
}
