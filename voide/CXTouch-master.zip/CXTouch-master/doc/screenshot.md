# Screenshots

![main frame](screenshot/mainframe.jpg)

Main Frame



![projection frame](screenshot/projection.jpg)

Projection Frame



![Setting Frame](screenshot/setting.jpg)

Setting Frame