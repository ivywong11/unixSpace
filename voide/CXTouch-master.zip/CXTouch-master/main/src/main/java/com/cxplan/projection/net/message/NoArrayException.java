package com.cxplan.projection.net.message;

/**
 * @author KennyLiu
 * @created on 2017/12/4
 */
public class NoArrayException extends Exception {

}
